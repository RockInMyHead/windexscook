import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import path from 'path';

// Initialize SQLite database in project root
const dbPath = path.join(process.cwd(), 'data.sqlite');
const db = new Database(dbPath);

// Create users table if not exists
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    subscription TEXT,
    created_at TEXT NOT NULL
  )
`);

// Create recipes table if not exists
db.exec(`
  CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    ingredients TEXT NOT NULL, -- JSON array
    instructions TEXT NOT NULL, -- JSON array
    cook_time TEXT,
    servings INTEGER,
    difficulty TEXT,
    category TEXT,
    cuisine TEXT,
    tips TEXT,
    image TEXT,
    author_id INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    rating REAL DEFAULT 0,
    likes INTEGER DEFAULT 0,
    favorites INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (author_id) REFERENCES users(id)
  )
`);

// Create comments table if not exists
db.exec(`
  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL,
    author_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    likes INTEGER DEFAULT 0,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id),
    FOREIGN KEY (author_id) REFERENCES users(id)
  )
`);

// Create user_likes table for tracking likes
db.exec(`
  CREATE TABLE IF NOT EXISTS user_likes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    recipe_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(user_id, recipe_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (recipe_id) REFERENCES recipes(id)
  )
`);

// Create user_favorites table for tracking favorites
db.exec(`
  CREATE TABLE IF NOT EXISTS user_favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    recipe_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(user_id, recipe_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (recipe_id) REFERENCES recipes(id)
  )
`);

export function getUserByEmail(email) {
  const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
  return stmt.get(email);
}

export function createUser(email, password) {
  const password_hash = bcrypt.hashSync(password, 10);
  const created_at = new Date().toISOString();
  const stmt = db.prepare('INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, ?)');
  const info = stmt.run(email, password_hash, created_at);
  return { id: info.lastInsertRowid, email, created_at };
}

export function updateUserPassword(email, newPassword) {
  const password_hash = bcrypt.hashSync(newPassword, 10);
  const stmt = db.prepare('UPDATE users SET password_hash = ? WHERE email = ?');
  stmt.run(password_hash, email);
}

export function updateUserSubscription(userId, subscriptionData) {
  const stmt = db.prepare('UPDATE users SET subscription = ? WHERE id = ?');
  stmt.run(JSON.stringify(subscriptionData), userId);
}

// Recipe functions
export function createRecipe(recipeData) {
  const stmt = db.prepare(`
    INSERT INTO recipes (
      title, description, ingredients, instructions, cook_time, 
      servings, difficulty, category, cuisine, tips, image, 
      author_id, created_at, updated_at, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  const now = new Date().toISOString();
  const result = stmt.run(
    recipeData.title,
    recipeData.description,
    JSON.stringify(recipeData.ingredients),
    JSON.stringify(recipeData.instructions),
    recipeData.cookTime,
    recipeData.servings,
    recipeData.difficulty,
    recipeData.category,
    recipeData.cuisine,
    recipeData.tips,
    recipeData.image,
    recipeData.authorId,
    now,
    now,
    recipeData.status || 'pending'
  );
  
  return result.lastInsertRowid;
}

export function getRecipes(filters = {}) {
  let query = `
    SELECT r.*, u.email as author_email 
    FROM recipes r 
    LEFT JOIN users u ON r.author_id = u.id 
    WHERE 1=1
  `;
  const params = [];
  
  if (filters.status) {
    query += ' AND r.status = ?';
    params.push(filters.status);
  } else {
    query += ' AND r.status = "approved"';
  }
  
  if (filters.category && filters.category !== 'all') {
    query += ' AND r.category = ?';
    params.push(filters.category);
  }
  
  if (filters.difficulty && filters.difficulty !== 'all') {
    query += ' AND r.difficulty = ?';
    params.push(filters.difficulty);
  }
  
  if (filters.search) {
    query += ' AND (r.title LIKE ? OR r.description LIKE ?)';
    const searchTerm = `%${filters.search}%`;
    params.push(searchTerm, searchTerm);
  }
  
  query += ' ORDER BY r.rating DESC, r.created_at DESC';
  
  if (filters.limit) {
    query += ' LIMIT ?';
    params.push(filters.limit);
  }
  
  if (filters.offset) {
    query += ' OFFSET ?';
    params.push(filters.offset);
  }
  
  const stmt = db.prepare(query);
  return stmt.all(...params);
}

export function getRecipeById(id) {
  const stmt = db.prepare(`
    SELECT r.*, u.email as author_email 
    FROM recipes r 
    LEFT JOIN users u ON r.author_id = u.id 
    WHERE r.id = ?
  `);
  return stmt.get(id);
}

export function updateRecipe(id, recipeData) {
  const stmt = db.prepare(`
    UPDATE recipes SET 
      title = ?, description = ?, ingredients = ?, instructions = ?, 
      cook_time = ?, servings = ?, difficulty = ?, category = ?, 
      cuisine = ?, tips = ?, image = ?, updated_at = ?
    WHERE id = ?
  `);
  
  const now = new Date().toISOString();
  stmt.run(
    recipeData.title,
    recipeData.description,
    JSON.stringify(recipeData.ingredients),
    JSON.stringify(recipeData.instructions),
    recipeData.cookTime,
    recipeData.servings,
    recipeData.difficulty,
    recipeData.category,
    recipeData.cuisine,
    recipeData.tips,
    recipeData.image,
    now,
    id
  );
}

export function deleteRecipe(id) {
  const stmt = db.prepare('DELETE FROM recipes WHERE id = ?');
  const result = stmt.run(id);
  return result.changes > 0;
}

export function likeRecipe(userId, recipeId) {
  const checkStmt = db.prepare('SELECT id FROM user_likes WHERE user_id = ? AND recipe_id = ?');
  const existing = checkStmt.get(userId, recipeId);
  
  if (existing) {
    // Unlike
    const deleteStmt = db.prepare('DELETE FROM user_likes WHERE user_id = ? AND recipe_id = ?');
    deleteStmt.run(userId, recipeId);
    
    const updateStmt = db.prepare('UPDATE recipes SET likes = likes - 1 WHERE id = ?');
    updateStmt.run(recipeId);
    
    return false;
  } else {
    // Like
    const insertStmt = db.prepare('INSERT INTO user_likes (user_id, recipe_id, created_at) VALUES (?, ?, ?)');
    insertStmt.run(userId, recipeId, new Date().toISOString());
    
    const updateStmt = db.prepare('UPDATE recipes SET likes = likes + 1 WHERE id = ?');
    updateStmt.run(recipeId);
    
    return true;
  }
}

export function favoriteRecipe(userId, recipeId) {
  const checkStmt = db.prepare('SELECT id FROM user_favorites WHERE user_id = ? AND recipe_id = ?');
  const existing = checkStmt.get(userId, recipeId);
  
  if (existing) {
    // Unfavorite
    const deleteStmt = db.prepare('DELETE FROM user_favorites WHERE user_id = ? AND recipe_id = ?');
    deleteStmt.run(userId, recipeId);
    
    const updateStmt = db.prepare('UPDATE recipes SET favorites = favorites - 1 WHERE id = ?');
    updateStmt.run(recipeId);
    
    return false;
  } else {
    // Favorite
    const insertStmt = db.prepare('INSERT INTO user_favorites (user_id, recipe_id, created_at) VALUES (?, ?, ?)');
    insertStmt.run(userId, recipeId, new Date().toISOString());
    
    const updateStmt = db.prepare('UPDATE recipes SET favorites = favorites + 1 WHERE id = ?');
    updateStmt.run(recipeId);
    
    return true;
  }
}

export function getCommentsByRecipeId(recipeId) {
  const stmt = db.prepare(`
    SELECT c.*, u.email as author_email 
    FROM comments c 
    LEFT JOIN users u ON c.author_id = u.id 
    WHERE c.recipe_id = ? 
    ORDER BY c.created_at DESC
  `);
  return stmt.all(recipeId);
}

export function createComment(commentData) {
  const stmt = db.prepare(`
    INSERT INTO comments (recipe_id, author_id, content, created_at) 
    VALUES (?, ?, ?, ?)
  `);
  
  const result = stmt.run(
    commentData.recipeId,
    commentData.authorId,
    commentData.content,
    new Date().toISOString()
  );
  
  // Update comments count
  const updateStmt = db.prepare('UPDATE recipes SET comments_count = comments_count + 1 WHERE id = ?');
  updateStmt.run(commentData.recipeId);
  
  return result.lastInsertRowid;
}

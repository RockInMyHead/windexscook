import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { HttpsProxyAgent } from 'https-proxy-agent';
import nodemailer from 'nodemailer';
import crypto from 'crypto';
import { 
  getUserByEmail, 
  updateUserPassword, 
  updateUserSubscription,
  createRecipe, 
  getRecipes, 
  getRecipeById, 
  updateRecipe, 
  deleteRecipe,
  likeRecipe,
  favoriteRecipe,
  getCommentsByRecipeId,
  createComment
} from './db.js';
import paymentRoutes from './routes/payments.js';

// Загружаем переменные окружения
dotenv.config();

// Настройка прокси - используем только env переменные, без fallback
const PROXY_HOST = process.env.PROXY_HOST;
const PROXY_PORT = process.env.PROXY_PORT;
const PROXY_USERNAME = process.env.PROXY_USERNAME;
const PROXY_PASSWORD = process.env.PROXY_PASSWORD;

// Создаем прокси агент для HTTPS только если все данные прокси указаны
const proxyUrl = PROXY_HOST && PROXY_PORT && PROXY_USERNAME && PROXY_PASSWORD 
  ? `http://${PROXY_USERNAME}:${PROXY_PASSWORD}@${PROXY_HOST}:${PROXY_PORT}`
  : null;

const proxyAgent = proxyUrl ? new HttpsProxyAgent(proxyUrl) : null;

console.log('🔧 Proxy configuration:', {
  proxyUrl: proxyUrl ? proxyUrl.replace(/:[^@]*@/, ':***@') : 'disabled', // Скрываем пароль в логах
  proxyHost: PROXY_HOST,
  proxyPort: PROXY_PORT,
  proxyUsername: PROXY_USERNAME,
  proxyEnabled: !!proxyAgent
});

// Создаем директорию для логов
const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Система отслеживания лимитов изображений
const imageLimitsFile = path.join(logsDir, 'image_limits.json');
const DAILY_IMAGE_LIMIT = 20;

// Функция для загрузки лимитов изображений
const loadImageLimits = () => {
  try {
    if (fs.existsSync(imageLimitsFile)) {
      const data = fs.readFileSync(imageLimitsFile, 'utf8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('Error loading image limits:', error);
  }
  return {};
};

// Функция для сохранения лимитов изображений
const saveImageLimits = (limits) => {
  try {
    fs.writeFileSync(imageLimitsFile, JSON.stringify(limits, null, 2));
  } catch (error) {
    console.error('Error saving image limits:', error);
  }
};

// Функция для очистки старых записей лимитов (старше 7 дней)
const cleanupOldLimits = (limits) => {
  const today = new Date();
  const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
  
  Object.keys(limits).forEach(userId => {
    Object.keys(limits[userId]).forEach(dateStr => {
      const recordDate = new Date(dateStr);
      if (recordDate < sevenDaysAgo) {
        delete limits[userId][dateStr];
      }
    });
    
    // Удаляем пустые объекты пользователей
    if (Object.keys(limits[userId]).length === 0) {
      delete limits[userId];
    }
  });
  
  return limits;
};

// Функция для проверки лимита изображений
const checkImageLimit = (userIdentifier) => {
  const limits = loadImageLimits();
  const today = new Date().toDateString();
  
  if (!limits[userIdentifier]) {
    limits[userIdentifier] = {};
  }
  
  if (!limits[userIdentifier][today]) {
    limits[userIdentifier][today] = 0;
  }
  
  // Очищаем старые записи
  const cleanedLimits = cleanupOldLimits(limits);
  if (cleanedLimits !== limits) {
    saveImageLimits(cleanedLimits);
  }
  
  return {
    canGenerate: limits[userIdentifier][today] < DAILY_IMAGE_LIMIT,
    currentCount: limits[userIdentifier][today],
    limit: DAILY_IMAGE_LIMIT
  };
};

// Функция для увеличения счетчика изображений
const incrementImageCount = (userIdentifier) => {
  const limits = loadImageLimits();
  const today = new Date().toDateString();
  
  if (!limits[userIdentifier]) {
    limits[userIdentifier] = {};
  }
  
  if (!limits[userIdentifier][today]) {
    limits[userIdentifier][today] = 0;
  }
  
  limits[userIdentifier][today]++;
  saveImageLimits(limits);
  
  return limits[userIdentifier][today];
};

// Функция для логирования
const logToFile = (level, message, data = null) => {
  const timestamp = new Date().toISOString();
  
  let logLine = `${timestamp} [${level}] ${message}`;
  
  if (data) {
    logLine += `\n${JSON.stringify(data, null, 2)}`;
  }
  
  logLine += '\n';
  
  // Логируем в консоль
  console.log(logLine.trim());
  
  // Логируем в файл
  const logFile = path.join(logsDir, `${new Date().toISOString().split('T')[0]}.log`);
  fs.appendFileSync(logFile, logLine);
};

// Middleware для логирования запросов
const requestLogger = (req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    logToFile('INFO', `${req.method} ${req.path} - ${res.statusCode} (${duration}ms)`, {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      userAgent: req.get('User-Agent'),
      ip: req.ip
    });
  });
  
  next();
};

const app = express();
const PORT = process.env.PORT || 1031;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(requestLogger);
app.use(express.json());
app.use('/api', paymentRoutes);

// Disable caching for all responses
app.disable('etag');
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// Static serve files from dist with no-cache for HTML
// API routes (must be before static files)
// Request password reset
app.post('/api/auth/request-password-reset', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });
  // Verify user exists
  const user = getUserByEmail(email);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const token = crypto.randomBytes(32).toString('hex');
  passwordResetTokens[token] = { email, expires: Date.now() + 3600000 }; // 1h
  const resetLink = `${process.env.FRONTEND_URL}/reset-password?token=${token}`;
  // await transporter.sendMail({
  //   from: process.env.SMTP_FROM,
  //   to: email,
  //   subject: 'Password Reset',
  //   text: `Click to reset your password: ${resetLink}`,
  // });
  console.log(`Password reset link: ${resetLink}`);
  res.json({ message: 'Password reset email sent' });
});

// Reset password
app.post('/api/auth/reset-password', async (req, res) => {
  const { token, newPassword } = req.body;
  const record = passwordResetTokens[token];
  if (!record || record.expires < Date.now()) return res.status(400).json({ error: 'Invalid or expired token' });
  try {
    // Update user password in DB
    updateUserPassword(record.email, newPassword);
    // Send email to user with the new password
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: record.email,
      subject: 'Ваш пароль обновлён',
      text: `Ваш пароль успешно сброшен. Ваш новый пароль: ${newPassword}`
    });
  } catch (err) {
    console.error('Password reset error:', err);
    return res.status(500).json({ error: 'Failed to reset password' });
  }
  delete passwordResetTokens[token];
  return res.json({ message: 'Password has been reset' });
});

// Create subscription for premium plan
app.post('/api/payment/create', async (req, res) => {
  try {
    const { userId, email } = req.body;
    if (!userId || !email) {
      return res.status(400).json({ error: 'User ID and email are required' });
    }
    // Create subscription via YooKassa Subscriptions API
    const response = await axios.post(
      'https://api.yookassa.ru/v3/subscriptions',
      {
        plan_id: '1183996',
        metadata: { userId, email },
        payer: { email }
      },
      { auth: { username: YOO_SHOP_ID, password: YOO_SECRET } }
    );
    const subscription = response.data;
    res.json({
      subscriptionId: subscription.id,
      confirmationUrl: subscription.confirmation.confirmation_url
    });
  } catch (error) {
    console.error('Subscription creation error:', error.response ? error.response.data : error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

// Handle YooKassa webhook
app.post('/api/payment/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const event = req.body;
    
    if (event.event === 'payment.succeeded') {
      const payment = event.object;
      const userId = payment.metadata.userId;
      const email = payment.metadata.email;
      
      // Activate premium subscription for user
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + 1);
      
      const subscriptionData = {
        active: true,
        expiresAt: expiresAt.toISOString(),
        plan: 'premium'
      };
      
      updateUserSubscription(userId, subscriptionData);
      console.log(`Premium subscription activated for user ${userId} (${email})`);
    }
    
    res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).send('Error');
  }
});

// Специальный endpoint для генерации рецептов
app.post('/api/openai/generate-recipe', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey || apiKey === 'your_openai_key_here') {
      logToFile('ERROR', 'WindexsAI API key not configured');
      return res.status(500).json({ 
        error: 'WindexsAI API key not configured',
        message: 'WindexsAI API key not configured'
      });
    }

    const { products, cookingStage } = req.body;
    
    if (!products || products.length === 0) {
      return res.status(400).json({ 
        error: 'Products are required' 
      });
    }

    const prompt = `Создай подробный рецепт на основе этих продуктов: ${products.join(', ')}.
Стадия готовки: ${cookingStage}.

Создай рецепт в формате JSON:
{
  "title": "Название рецепта",
  "description": "Краткое описание блюда",
  "ingredients": ["ингредиент1", "ингредиент2"],
  "steps": [
    {
      "description": "Описание шага",
      "time": "5 минут"
    }
  ],
  "difficulty": "легкий/средний/сложный",
  "servings": 4
}`;

    const openaiRequest = {
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 1500,
      temperature: 0.7
    };

    logToFile('INFO', 'Generating recipe with WindexsAI', {
      products: products,
      cookingStage: cookingStage
    });

    const axiosConfig = {
      method: 'POST',
      url: 'https://api.openai.com/v1/chat/completions',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(openaiRequest),
      proxy: false
    };
    
    if (proxyAgent) {
      axiosConfig.httpsAgent = proxyAgent;
      axiosConfig.httpAgent = proxyAgent;
    }

    const response = await axios(axiosConfig);
    const content = response.data.choices[0].message.content;
    
    try {
      const recipe = JSON.parse(content);
      logToFile('INFO', 'Recipe generated successfully', {
        title: recipe.title,
        stepsCount: recipe.steps?.length || 0
      });
      res.json(recipe);
    } catch (parseError) {
      // Fallback если не удалось распарсить JSON
      const fallbackRecipe = {
        title: `Рецепт из ${products.join(', ')}`,
        description: `Вкусное блюдо из доступных ингредиентов`,
        ingredients: products,
        steps: [
          {
            description: `Подготовьте ${products.join(', ')}`,
            time: "10 минут"
          },
          {
            description: "Нарежьте ингредиенты",
            time: "15 минут"
          },
          {
            description: "Приготовьте блюдо",
            time: "20 минут"
          }
        ],
        difficulty: "средний",
        servings: 4
      };
      
      res.json(fallbackRecipe);
    }

  } catch (error) {
    logToFile('ERROR', 'Recipe generation error', {
      error: error.message,
      stack: error.stack
    });
    
    res.status(500).json({ 
      error: 'Recipe generation failed',
      details: error.message 
    });
  }
});

// Специальный endpoint для анализа изображений с WindexsAI Vision
app.post('/api/openai/analyze-image', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey || apiKey === 'your_openai_key_here') {
      logToFile('ERROR', 'WindexsAI API key not configured');
      return res.status(500).json({ 
        error: 'WindexsAI API key not configured',
        message: 'WindexsAI API key not configured'
      });
    }

    const { image, prompt } = req.body;
    
    if (!image || !prompt) {
      return res.status(400).json({ 
        error: 'Image and prompt are required' 
      });
    }

    // Подготавливаем запрос к WindexsAI Vision API
    const openaiRequest = {
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: prompt
            },
            {
              type: "image_url",
              image_url: {
                url: image
              }
            }
          ]
        }
      ],
      max_tokens: 1000,
      temperature: 0.3
    };

    logToFile('INFO', 'Analyzing image with WindexsAI Vision', {
      prompt: prompt.substring(0, 100) + '...',
      imageSize: image.length
    });

    const axiosConfig = {
      method: 'POST',
      url: 'https://api.openai.com/v1/chat/completions',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(openaiRequest),
      proxy: false
    };
    
    // Добавляем прокси агент только если он настроен
    if (proxyAgent) {
      axiosConfig.httpsAgent = proxyAgent;
      axiosConfig.httpAgent = proxyAgent;
    }

    const response = await axios(axiosConfig);
    
    // Парсим ответ от WindexsAI
    const content = response.data.choices[0].message.content;
    
    try {
      // Пытаемся распарсить JSON ответ
      const parsedResult = JSON.parse(content);
      
      logToFile('INFO', 'Image analysis completed', {
        products: parsedResult.products,
        cookingStage: parsedResult.cookingStage,
        suggestionsCount: parsedResult.suggestions?.length || 0
      });
      
      res.json(parsedResult);
    } catch (parseError) {
      // Если не удалось распарсить JSON, возвращаем структурированный ответ
      console.log('⚠️ Could not parse WindexsAI response as JSON, using fallback');
      
      const fallbackResult = {
        products: extractProductsFromText(content),
        cookingStage: 'preparation',
        suggestions: extractSuggestionsFromText(content)
      };
      
      res.json(fallbackResult);
    }

  } catch (error) {
    logToFile('ERROR', 'Image analysis error', {
      error: error.message,
      stack: error.stack
    });
    
    res.status(500).json({ 
      error: 'Image analysis failed',
      details: error.message 
    });
  }
});

// WindexsAI Chat Completions endpoint
app.post('/api/openai/v1/chat/completions', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey || apiKey === 'your_openai_key_here') {
      logToFile('ERROR', 'WindexsAI API key not configured');
      return res.status(500).json({ 
        error: 'WindexsAI API key not configured',
        message: 'WindexsAI API key not configured'
      });
    }

    const { model, messages, temperature, max_tokens } = req.body;
    
    if (!model || !messages) {
      return res.status(400).json({ 
        error: 'Model and messages are required' 
      });
    }

    const openaiRequest = {
      model: model || 'gpt-4o-mini',
      messages: messages,
      temperature: temperature || 0.8,
      max_tokens: max_tokens || 15000
    };

    logToFile('INFO', 'WindexsAI Chat Completions request', {
      model: openaiRequest.model,
      messagesCount: messages.length,
      temperature: openaiRequest.temperature
    });

    const axiosConfig = {
      method: 'POST',
      url: 'https://api.openai.com/v1/chat/completions',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(openaiRequest),
      proxy: false
    };
    
    if (proxyAgent) {
      axiosConfig.httpsAgent = proxyAgent;
      axiosConfig.httpAgent = proxyAgent;
    }

    const response = await axios(axiosConfig);
    
    logToFile('INFO', 'WindexsAI Chat Completions response received', {
      model: response.data.model,
      usage: response.data.usage
    });
    
    res.json(response.data);

  } catch (error) {
    logToFile('ERROR', 'WindexsAI Chat Completions error', {
      error: error.message,
      stack: error.stack,
      response: error.response?.data
    });
    
    if (error.response) {
      res.status(error.response.status).json({ 
        error: 'WindexsAI API error',
        details: error.response.data 
      });
    } else {
      res.status(500).json({ 
        error: 'Internal server error',
        details: error.message 
      });
    }
  }
});

// Recipes API endpoints
app.get('/api/recipes', async (req, res) => {
  try {
    const { 
      category = 'all', 
      difficulty = 'all', 
      search = '', 
      limit = 10, 
      offset = 0,
      status = 'approved'
    } = req.query;

    const filters = {
      category: category !== 'all' ? category : undefined,
      difficulty: difficulty !== 'all' ? difficulty : undefined,
      search: search || undefined,
      limit: parseInt(limit),
      offset: parseInt(offset),
      status
    };

    const recipes = getRecipes(filters);
    
    // Parse JSON fields
    const formattedRecipes = recipes.map(recipe => ({
      ...recipe,
      ingredients: JSON.parse(recipe.ingredients),
      instructions: JSON.parse(recipe.instructions)
    }));

    res.json(formattedRecipes);
  } catch (error) {
    console.error('Error fetching recipes:', error);
    res.status(500).json({ error: 'Failed to fetch recipes' });
  }
});

app.get('/api/recipes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = getRecipeById(id);
    
    if (!recipe) {
      return res.status(404).json({ error: 'Recipe not found' });
    }

    // Parse JSON fields
    const formattedRecipe = {
      ...recipe,
      ingredients: JSON.parse(recipe.ingredients),
      instructions: JSON.parse(recipe.instructions)
    };

    res.json(formattedRecipe);
  } catch (error) {
    console.error('Error fetching recipe:', error);
    res.status(500).json({ error: 'Failed to fetch recipe' });
  }
});

app.post('/api/recipes', async (req, res) => {
  try {
    const recipeData = req.body;
    
    if (!recipeData.title || !recipeData.ingredients || !recipeData.instructions) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const recipeId = createRecipe({
      ...recipeData,
      authorId: req.user?.id || 1, // Default to user 1 if not authenticated
      status: 'pending'
    });

    const newRecipe = getRecipeById(recipeId);
    const formattedRecipe = {
      ...newRecipe,
      ingredients: JSON.parse(newRecipe.ingredients),
      instructions: JSON.parse(newRecipe.instructions)
    };

    res.status(201).json(formattedRecipe);
  } catch (error) {
    console.error('Error creating recipe:', error);
    res.status(500).json({ error: 'Failed to create recipe' });
  }
});

app.put('/api/recipes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const recipeData = req.body;
    
    updateRecipe(id, recipeData);
    
    const updatedRecipe = getRecipeById(id);
    if (!updatedRecipe) {
      return res.status(404).json({ error: 'Recipe not found' });
    }

    const formattedRecipe = {
      ...updatedRecipe,
      ingredients: JSON.parse(updatedRecipe.ingredients),
      instructions: JSON.parse(updatedRecipe.instructions)
    };

    res.json(formattedRecipe);
  } catch (error) {
    console.error('Error updating recipe:', error);
    res.status(500).json({ error: 'Failed to update recipe' });
  }
});

app.delete('/api/recipes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const success = deleteRecipe(id);
    
    if (!success) {
      return res.status(404).json({ error: 'Recipe not found' });
    }

    res.json({ message: 'Recipe deleted successfully' });
  } catch (error) {
    console.error('Error deleting recipe:', error);
    res.status(500).json({ error: 'Failed to delete recipe' });
  }
});

app.post('/api/recipes/:id/like', async (req, res) => {
  try {
    const { id } = recipeId = req.params;
    const userId = req.user?.id || 1; // Default to user 1 if not authenticated
    
    const isLiked = likeRecipe(userId, recipeId);
    
    res.json({ liked: isLiked });
  } catch (error) {
    console.error('Error liking recipe:', error);
    res.status(500).json({ error: 'Failed to like recipe' });
  }
});

app.post('/api/recipes/:id/favorite', async (req, res) => {
  try {
    const { id: recipeId } = req.params;
    const userId = req.user?.id || 1; // Default to user 1 if not authenticated
    
    const isFavorited = favoriteRecipe(userId, recipeId);
    
    res.json({ favorited: isFavorited });
  } catch (error) {
    console.error('Error favoriting recipe:', error);
    res.status(500).json({ error: 'Failed to favorite recipe' });
  }
});

app.get('/api/recipes/:id/comments', async (req, res) => {
  try {
    const { id: recipeId } = req.params;
    const comments = getCommentsByRecipeId(recipeId);
    
    res.json(comments);
  } catch (error) {
    console.error('Error fetching comments:', error);
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

app.post('/api/recipes/:id/comments', async (req, res) => {
  try {
    const { id: recipeId } = req.params;
    const { content } = req.body;
    const userId = req.user?.id || 1; // Default to user 1 if not authenticated
    
    if (!content) {
      return res.status(400).json({ error: 'Comment content is required' });
    }

    const commentId = createComment({
      recipeId,
      authorId: userId,
      content
    });

    res.status(201).json({ id: commentId, message: 'Comment created successfully' });
  } catch (error) {
    console.error('Error creating comment:', error);
    res.status(500).json({ error: 'Failed to create comment' });
  }
});

app.use(express.static('dist', {
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));

// Explicit route for root to ensure proper handling
app.get('/', (req, res) => {
  // Force cache invalidation for Telegram and other bots
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.setHeader('Last-Modified', new Date().toUTCString());
  res.setHeader('ETag', `"${Date.now()}"`);
  
  res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
});

// ElevenLabs API роут - используем middleware для обработки всех запросов
app.use('/api/elevenlabs', async (req, res) => {
  try {
    const apiKey = process.env.ELEVENLABS_API_KEY;
    
    if (!apiKey) {
      logToFile('ERROR', 'ElevenLabs API key not configured');
      return res.status(500).json({ 
        error: 'ElevenLabs API key not configured' 
      });
    }

    // Получаем путь после /api/elevenlabs и добавляем /v1
    const path = req.path.replace('/api/elevenlabs', '/v1');
    const url = `https://api.elevenlabs.io${path}`;

    logToFile('INFO', `Proxying ElevenLabs ${req.method} request to: ${url}`, {
      url,
      method: req.method,
      path: req.path,
      body: req.body
    });

    // Создаем заголовки для запроса к ElevenLabs
    const headers = {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      ...req.headers
    };

    // Удаляем host заголовок, чтобы избежать конфликтов
    delete headers.host;

    const axiosConfig = {
      method: req.method,
      url: url,
      headers,
      data: req.method !== 'GET' ? JSON.stringify(req.body) : undefined,
      proxy: false // Отключаем автоопределение прокси из env переменных
    };
    
    // Добавляем прокси агент только если он настроен
    if (proxyAgent) {
      axiosConfig.httpsAgent = proxyAgent;
      axiosConfig.httpAgent = proxyAgent;
    }
    
    const response = await axios(axiosConfig);

    const data = JSON.stringify(response.data);
    
    logToFile('INFO', `ElevenLabs response received: ${response.status}`, {
      status: response.status,
      responseSize: `${data.length} bytes`,
      url
    });

    res.status(response.status).send(data);
  } catch (error) {
    logToFile('ERROR', 'ElevenLabs Proxy error', {
      error: error.message,
      stack: error.stack,
      url: `https://api.elevenlabs.io${req.path.replace('/api/elevenlabs', '/v1')}`
    });
    
    // Обрабатываем ошибки axios (включая 4xx/5xx статусы)
    if (error.response) {
      const data = JSON.stringify(error.response.data);
      res.status(error.response.status).send(data);
    } else {
      res.status(500).json({ 
        error: 'Internal server error',
        details: error.message 
      });
    }
  }
});

// Вспомогательные функции для парсинга ответов WindexsAI
function extractProductsFromText(text) {
  const products = [];
  const lines = text.split('\n');
  
  // Ищем строки с продуктами
  for (const line of lines) {
    const lowerLine = line.toLowerCase();
    
    // Ищем яйца
    if (lowerLine.includes('яйц') || lowerLine.includes('egg')) {
      products.push('Яйца');
    }
    // Ищем помидоры
    if (lowerLine.includes('помидор') || lowerLine.includes('томат') || lowerLine.includes('tomato')) {
      products.push('Помидоры');
    }
    // Ищем мясо
    if (lowerLine.includes('мясо') || lowerLine.includes('говядин') || lowerLine.includes('свинин') || lowerLine.includes('курин') || lowerLine.includes('meat') || lowerLine.includes('beef') || lowerLine.includes('chicken')) {
      products.push('Мясо');
    }
    // Ищем овощи
    if (lowerLine.includes('овощ') || lowerLine.includes('овощ') || lowerLine.includes('vegetable')) {
      products.push('Овощи');
    }
    // Ищем картофель
    if (lowerLine.includes('картофель') || lowerLine.includes('картошк') || lowerLine.includes('potato')) {
      products.push('Картофель');
    }
    // Ищем перец
    if (lowerLine.includes('перец') || lowerLine.includes('pepper')) {
      products.push('Перец');
    }
    // Ищем лук
    if (lowerLine.includes('лук') || lowerLine.includes('onion')) {
      products.push('Лук');
    }
    // Ищем морковь
    if (lowerLine.includes('морковь') || lowerLine.includes('carrot')) {
      products.push('Морковь');
    }
  }
  
  // Убираем дубликаты
  return [...new Set(products)].slice(0, 4);
}

function extractSuggestionsFromText(text) {
  const suggestions = [];
  const lines = text.split('\n');
  
  for (const line of lines) {
    const cleanLine = line.trim();
    
    // Ищем советы по готовке
    if (cleanLine.length > 15 && (
      cleanLine.includes('совет') || 
      cleanLine.includes('рекоменд') || 
      cleanLine.includes('следующий') ||
      cleanLine.includes('можно') ||
      cleanLine.includes('стоит') ||
      cleanLine.includes('•') ||
      cleanLine.includes('-') ||
      cleanLine.includes('1.') ||
      cleanLine.includes('2.') ||
      cleanLine.includes('3.')
    )) {
      const suggestion = cleanLine.replace(/^[•\-\d\.\s]+/, '').trim();
      if (suggestion.length > 10) {
        suggestions.push(suggestion);
      }
    }
  }
  
  // Если не нашли советы, добавляем общие
  if (suggestions.length === 0) {
    suggestions.push('Проверьте свежесть продуктов');
    suggestions.push('Подготовьте все ингредиенты заранее');
    suggestions.push('Следуйте рецепту пошагово');
  }
  
  return suggestions.slice(0, 3);
}

// WindexsAI API роут - проксирование для WindexsAI
app.use('/api/openai', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey || apiKey === 'your_openai_key_here') {
      logToFile('ERROR', 'WindexsAI API key not configured');
      return res.status(500).json({ 
        error: 'WindexsAI API key not configured',
        message: 'WindexsAI API key not configured'
      });
    }

    // Получаем путь после /api/openai
    const path = req.path.replace('/api/openai', '');
    const url = `https://api.openai.com${path}`;

    // Создаем заголовки для запроса к WindexsAI
    const headers = {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      ...req.headers
    };

    // Удаляем host заголовок, чтобы избежать конфликтов
    delete headers.host;
  // Логируем запрос вместе с заголовками после их создания
  logToFile('INFO', `Proxying WindexsAI ${req.method} request to: ${url}`, {
    url,
    method: req.method,
    path: req.path,
    body: req.body,
    headers: headers
  });

  // Дополнительное логирование для отладки
  console.log('🔍 DEBUG: WindexsAI Request Details:', {
    url,
    method: req.method,
    headers: headers,
    body: req.body,
    proxyEnv: {
      HTTP_PROXY: process.env.HTTP_PROXY,
      HTTPS_PROXY: process.env.HTTPS_PROXY
    }
  });

    try {
      console.log(`🚀 Sending axios request ${proxyAgent ? 'with proxy agent' : 'WITHOUT proxy'}...`);
      
      const axiosConfig = {
        method: req.method,
        url: url,
        headers,
        data: req.method !== 'GET' ? JSON.stringify(req.body) : undefined,
        proxy: false, // Отключаем автоопределение прокси из env переменных
        timeout: 30000, // 30 секунд таймаут
        maxRedirects: 5,
        validateStatus: function (status) {
          return status >= 200 && status < 300; // Разрешаем только успешные статусы
        }
      };
      
      // Отключаем прокси для WindexsAI API
      // if (proxyAgent) {
      //   axiosConfig.httpsAgent = proxyAgent;
      //   axiosConfig.httpAgent = proxyAgent;
      // }
      
      const response = await axios(axiosConfig);

      const data = JSON.stringify(response.data);
      
      console.log('✅ WindexsAI response received:', {
        status: response.status,
        responseSize: `${data.length} bytes`,
        url,
        dataPreview: data.substring(0, 200) + '...'
      });
      
      logToFile('INFO', `WindexsAI response received: ${response.status}`, {
        status: response.status,
        responseSize: `${data.length} bytes`,
        url
      });

      res.status(response.status).send(data);
    } catch (axiosError) {
      console.log('❌ Axios error occurred:', {
        message: axiosError.message,
        code: axiosError.code,
        status: axiosError.response?.status,
        responseData: axiosError.response?.data,
        url: axiosError.config?.url
      });
      
      // Обрабатываем ошибки axios (включая 4xx/5xx статусы)
      if (axiosError.response) {
        const data = JSON.stringify(axiosError.response.data);
        console.log('📝 Error response data:', data);
        
        logToFile('INFO', `WindexsAI response received: ${axiosError.response.status}`, {
          status: axiosError.response.status,
          responseSize: `${data.length} bytes`,
          url
        });
        res.status(axiosError.response.status).send(data);
      } else {
        console.log('🚨 Network error:', axiosError.message);
        throw axiosError;
      }
    }
  } catch (error) {
    logToFile('ERROR', 'WindexsAI Proxy error', {
      error: error.message,
      stack: error.stack,
      url: `https://api.openai.com${req.path.replace('/api/openai', '')}`
    });
    res.status(500).json({ 
      error: 'Internal server error',
      details: error.message 
    });
  }
});

// Image generation endpoint
app.post('/api/generate-nb-image', async (req, res) => {
  try {
    const { prompt, userIdentifier } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ 
        error: 'Prompt is required' 
      });
    }

    // Проверяем лимит изображений для пользователя
    const userKey = userIdentifier || req.ip || 'anonymous';
    const limitCheck = checkImageLimit(userKey);
    
    if (!limitCheck.canGenerate) {
      logToFile('INFO', `Image generation limit exceeded for user: ${userKey}`, {
        currentCount: limitCheck.currentCount,
        limit: limitCheck.limit
      });
      
      return res.status(429).json({ 
        error: 'Daily image generation limit exceeded',
        currentCount: limitCheck.currentCount,
        limit: limitCheck.limit,
        message: `Вы достигли дневного лимита генерации изображений (${limitCheck.limit}). Попробуйте завтра.`
      });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey) {
      logToFile('ERROR', 'WindexsAI API key not configured for image generation');
      return res.status(500).json({ 
        error: 'WindexsAI API key not configured' 
      });
    }

    logToFile('INFO', `Generating image for prompt: ${prompt}`, {
      userKey,
      currentCount: limitCheck.currentCount,
      limit: limitCheck.limit
    });

    // Создаем заголовки для запроса к WindexsAI
    const headers = {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    };

    const imageRequest = {
      model: "dall-e-3",
      prompt: prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
      response_format: "b64_json"
    };

    const axiosConfig = {
      method: 'POST',
      url: 'https://api.openai.com/v1/images/generations',
      headers,
      data: JSON.stringify(imageRequest),
      proxy: false,
      timeout: 60000, // 60 секунд для генерации изображений
      maxRedirects: 5,
      validateStatus: function (status) {
        return status >= 200 && status < 300;
      },
      // httpsAgent: new (await import('https')).default.Agent({
      //   keepAlive: true,
      //   timeout: 60000
      // })
    };
    
    // Отключаем прокси для генерации изображений
    // if (proxyAgent) {
    //   axiosConfig.httpsAgent = proxyAgent;
    //   axiosConfig.httpAgent = proxyAgent;
    // }
    
    const response = await axios(axiosConfig);

    if (response.data && response.data.data && response.data.data[0] && response.data.data[0].b64_json) {
      const imageBase64 = response.data.data[0].b64_json;
      
      // Увеличиваем счетчик изображений для пользователя
      const newCount = incrementImageCount(userKey);
      
      logToFile('INFO', `Image generated successfully for prompt: ${prompt}`, {
        userKey,
        newCount,
        limit: limitCheck.limit
      });
      
      res.json({ 
        image_base64: imageBase64,
        currentCount: newCount,
        limit: limitCheck.limit
      });
    } else {
      logToFile('ERROR', 'Invalid response format from WindexsAI image generation');
      res.status(500).json({ 
        error: 'Invalid response from image generation service' 
      });
    }

  } catch (error) {
    logToFile('ERROR', 'Image generation error', {
      error: error.message,
      stack: error.stack,
      prompt: req.body.prompt
    });
    
    if (error.response) {
      const data = JSON.stringify(error.response.data);
      res.status(error.response.status).send(data);
    } else {
      res.status(500).json({ 
        error: 'Internal server error',
        details: error.message 
      });
    }
  }
});

// Check image generation limits endpoint
app.get('/api/image-limits/:userIdentifier', (req, res) => {
  try {
    const { userIdentifier } = req.params;
    const userKey = userIdentifier || req.ip || 'anonymous';
    const limitCheck = checkImageLimit(userKey);
    
    res.json({
      canGenerate: limitCheck.canGenerate,
      currentCount: limitCheck.currentCount,
      limit: limitCheck.limit,
      remaining: limitCheck.limit - limitCheck.currentCount
    });
  } catch (error) {
    logToFile('ERROR', 'Error checking image limits', {
      error: error.message,
      userIdentifier: req.params.userIdentifier
    });
    res.status(500).json({ 
      error: 'Internal server error',
      details: error.message 
    });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'Pastel Chef AI API Server'
  });
});

// Fallback для SPA - все остальные запросы возвращают index.html
app.use((req, res) => {
  // Отключаем кэширование для HTML файлов
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.sendFile('dist/index.html', { root: '.' });
});

// In-memory store for reset tokens (for demo; replace with DB in production)
const passwordResetTokens = {};

// YooKassa credentials
const YOO_SHOP_ID = process.env.YOOKASSA_SHOP_ID || '1017311';
const YOO_SECRET = process.env.YOOKASSA_SECRET_KEY || 'live_tHijAoMLOVGy_Caw-tQuQOfRdoZk-5vKaMLtDNEXmcc';

// SMTP transporter - using Ethereal Email for testing (free, no real SMTP needed)
const transporter = nodemailer.createTransport({
  host: 'smtp.ethereal.email',
  port: 587,
  secure: false,
  auth: {
    user: 'ethereal.user@ethereal.email',
    pass: 'ethereal.pass',
  },
});


app.listen(PORT, () => {
  logToFile('INFO', `Pastel Chef AI API server started`, {
    port: PORT,
    elevenlabsConfigured: !!process.env.ELEVENLABS_API_KEY,
    openaiConfigured: !!process.env.VITE_OPENAI_API_KEY,
    proxyConfigured: true,
    proxyHost: PROXY_HOST,
    proxyPort: PROXY_PORT,
    proxyUsername: PROXY_USERNAME,
    logsDirectory: logsDir,
    serverUrl: `http://localhost:${PORT}`
  });
  
  console.log(`🚀 Pastel Chef AI API server running on port ${PORT}`);
  console.log(`🔑 ElevenLabs API key configured: ${process.env.ELEVENLABS_API_KEY ? 'Yes' : 'No'}`);
  console.log(`🔑 WindexsAI API key configured: ${process.env.VITE_OPENAI_API_KEY ? 'Yes' : 'No'}`);
  console.log(`🌐 Proxy configured: ${PROXY_HOST}:${PROXY_PORT} (${PROXY_USERNAME})`);
  console.log(`📁 Logs directory: ${logsDir}`);
  console.log(`🌐 Server URL: http://localhost:${PORT}`);
});
